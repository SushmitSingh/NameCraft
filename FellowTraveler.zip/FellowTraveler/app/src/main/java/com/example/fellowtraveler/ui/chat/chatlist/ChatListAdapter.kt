package com.example.fellowtraveler.ui.chat.chatlist

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.fellowtraveler.data.chat.ChatListModel
import com.example.fellowtraveler.databinding.ItemChatListBinding

class ChatListAdapter(private val dataList: List<ChatListModel>, private val listener: OnItemClickListener) :
    RecyclerView.Adapter<ChatListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemChatListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val dataItem = dataList[position]
        holder.itemView.setOnClickListener {
            listener.onItemClick(position)
        }
        holder.bind(dataItem)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    class ViewHolder(private val binding: ItemChatListBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataItem: ChatListModel) {
            binding.data = dataItem
            binding.executePendingBindings()
        }
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }
}