package com.example.fellowtraveler.ui.profile

import androidx.lifecycle.ViewModel

class EditProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}