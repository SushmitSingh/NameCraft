package com.example.fellowtraveler.ui.subscription.annually

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.fellowtraveler.R

class AnnuallyPayFragment : Fragment() {

    companion object {
        fun newInstance() = AnnuallyPayFragment()
    }

    private lateinit var viewModel: AnnuallyPayViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_annually_pay, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(AnnuallyPayViewModel::class.java)
        // TODO: Use the ViewModel
    }

}