package com.example.fellowtraveler.ui.subscription

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.fellowtraveler.R
import com.example.fellowtraveler.databinding.FragmentSubscriptionBinding
import com.example.fellowtraveler.ui.subscription.annually.AnnuallyPayFragment
import com.example.fellowtraveler.ui.subscription.monthly.MonthlyPayFragment
import com.google.android.material.tabs.TabLayoutMediator

class SubscriptionFragment : Fragment() {

    private var _binding: FragmentSubscriptionBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val subscriptionViewModel =
            ViewModelProvider(this).get(SubscriptionViewModel::class.java)

        _binding = FragmentSubscriptionBinding.inflate(inflater, container, false)
        val root: View = binding.root

       /* *//* val textView: TextView = binding.textGallery
         subscriptionViewModel.text.observe(viewLifecycleOwner) {
             textView.text = it
         }*//*
        //Set TabLayout with ViewPager2
        val tabLayout = binding.tabLayout
        val viewPager2 = binding.viewPager
        viewPager2.adapter = DemoCollectionAdapter(this)
        TabLayoutMediator(tabLayout, viewPager2) { tab, position ->
            when (position) {
                0 -> tab.text = getString(R.string.monthly)
                1 -> tab.text = getString(R.string.annually)
            }
        }.attach()*/


        return root
    }

    class DemoCollectionAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {

        override fun getItemCount(): Int = 2

        override fun createFragment(position: Int): Fragment {
            val fragment = when (position) {
                0 -> MonthlyPayFragment()
                1 -> AnnuallyPayFragment()
                else -> DemoObjectFragment()
            }
            return fragment
        }
    }

    class DemoObjectFragment : Fragment() {

        override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View {
            return inflater.inflate(R.layout.fragment_chat_list, container, false)
        }

        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}