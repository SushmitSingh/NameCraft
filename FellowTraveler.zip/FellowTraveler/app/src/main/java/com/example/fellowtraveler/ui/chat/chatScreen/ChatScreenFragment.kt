package com.example.fellowtraveler.ui.chat.chatScreen

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.fellowtraveler.R
import com.example.fellowtraveler.databinding.FragmentChatScreenBinding

class ChatScreenFragment : Fragment() {

    private lateinit var binding: FragmentChatScreenBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentChatScreenBinding.inflate(inflater, container, false)
        return binding.root
    }

}