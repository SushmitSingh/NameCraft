package com.example.fellowtraveler.ui.auth.onboarding

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.example.fellowtraveler.R
import com.example.fellowtraveler.databinding.FragmentOnBoardingBinding
import com.tbuonomo.viewpagerdotsindicator.SpringDotsIndicator

class OnBoardingFragment : Fragment() {

    private lateinit var viewPager: ViewPager2
    private lateinit var adapter: OnboardPagerAdapter

    private var _binding: FragmentOnBoardingBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentOnBoardingBinding.inflate(inflater, container, false)
        viewPager = binding.viewPager2

        adapter = OnboardPagerAdapter(childFragmentManager, lifecycle)
        adapter.addBoardingLayout(
            BoardingLayout.newInstance(
                R.drawable.ic_1,
                "Explore \n" +
                        "Exotic Destinations",
                "Embark on a virtual journey through stunning destinations worldwide."
            )
        )
        adapter.addBoardingLayout(
            BoardingLayout.newInstance(
                R.drawable.ic_2,
                "Discover \n" +
                        "Local Gems",
                "Uncover hidden gems and local favorites recommended by fellow travelers."
            )
        )
        adapter.addBoardingLayout(
            BoardingLayout.newInstance(
                R.drawable.ic_3,
                "Plan \n" +
                        "Your Perfect Trip",
                "Create personalized itineraries tailored to your preferences and interests."
            )
        )
        adapter.addBoardingLayout(
            BoardingLayout.newInstance(
                R.drawable.ic_4,
                "Capture and Share Memories",
                "Preserve your travel memories with our in-app photo and journaling features."
            )
        )



        viewPager.adapter = adapter


        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.springDotsIndicator.setViewPager2(viewPager)

        binding.button.setOnClickListener {
            findNavController().navigate(R.id.action_onBoardingFragment_to_loginFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_POSITION = "ARG_POSITION"

        fun getInstance(position: Int) = OnBoardingFragment().apply {
            arguments = bundleOf(ARG_POSITION to position)
        }
    }
}

class OnboardPagerAdapter(
    fragmentManager: FragmentManager,
    lifecycle: Lifecycle
) : FragmentStateAdapter(fragmentManager, lifecycle) {

    private val boardingLayouts = mutableListOf<BoardingLayout>()

    override fun getItemCount(): Int = boardingLayouts.size

    override fun createFragment(position: Int): Fragment = boardingLayouts[position]

    @SuppressLint("NotifyDataSetChanged")
    fun addBoardingLayout(boardingLayout: BoardingLayout) {
        boardingLayouts.add(boardingLayout)
        notifyDataSetChanged()
    }
}