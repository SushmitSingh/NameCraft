package com.example.fellowtraveler.data.chat

data class ChatListModel(
    val name: String,
    val message: String,
    val time: String,
    val image: String
)
