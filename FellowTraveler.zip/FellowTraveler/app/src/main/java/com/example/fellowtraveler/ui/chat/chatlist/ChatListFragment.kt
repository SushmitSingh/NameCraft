package com.example.fellowtraveler.ui.chat.chatlist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fellowtraveler.R
import com.example.fellowtraveler.data.chat.ChatListModel
import com.example.fellowtraveler.databinding.FragmentChatListBinding

class ChatListFragment : Fragment(), ChatListAdapter.OnItemClickListener {
    private lateinit var binding: FragmentChatListBinding

    private var dataList: List<ChatListModel> = ArrayList()
    private lateinit var adapter: ChatListAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FragmentChatListBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val recyclerView = binding.chatListRecyclerView
        dataList = createSampleData()
        adapter = ChatListAdapter(dataList, this)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

        return root
    }

    private fun createSampleData(): List<ChatListModel> {
        val sampleDataList = ArrayList<ChatListModel>()
        sampleDataList.add(
            ChatListModel(
                "Albert Dera",
                "Hello",
                "12:00",
                "https://example.com/image1.jpg"
            )
        )
        sampleDataList.add(
            ChatListModel(
                "Emma Watson",
                "Hi",
                "12:00",
                "https://example.com/image2.jpg"
            )
        )
        sampleDataList.add(
            ChatListModel(
                "John Doe",
                "Hello",
                "12:00",
                "https://example.com/image3.jpg"
            )
        )
        return sampleDataList
    }

    override fun onItemClick(position: Int) {
        findNavController().navigate(R.id.action_nav_chat_to_chatScreenFragment)
    }

}