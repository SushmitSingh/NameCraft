package com.example.fellowtraveler.ui.subscription.annually

import androidx.lifecycle.ViewModel

class AnnuallyPayViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}