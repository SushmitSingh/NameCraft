package com.example.fellowtraveler.ui.profile

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fellowtraveler.R
import com.example.fellowtraveler.data.home.TourmateModel
import com.example.fellowtraveler.databinding.FragmentHomeBinding
import com.example.fellowtraveler.databinding.FragmentProfileBinding
import com.example.fellowtraveler.ui.home.TouristAdapter

class ProfileFragment : Fragment() {

 private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: TouristAdapter
    private var dataList: List<TourmateModel> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val recyclerView = binding.recyclerView
        // Add some sample data to the dataList
        dataList = createSampleData() // Replace this with your actual data source or API call
        // Initialize the adapter and set it to the RecyclerView
        adapter = TouristAdapter(dataList)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

        binding.btnEdit.setOnClickListener {
            findNavController().navigate(R.id.action_nav_profile_to_editProfileFragment)
        }

        return root
    }

    private fun createSampleData(): List<TourmateModel> {
        val sampleDataList = ArrayList<TourmateModel>()
        sampleDataList.add(TourmateModel("Albert Dera", 21, "UP. Noida to Agara", "https://example.com/image1.jpg"))
        sampleDataList.add(TourmateModel("Emma Watson", 25, "London to Paris", "https://example.com/image2.jpg"))
        sampleDataList.add(TourmateModel("John Doe", 30, "New York to Los Angeles", "https://example.com/image3.jpg"))
        // Add more sample data as needed
        return sampleDataList
    }
}