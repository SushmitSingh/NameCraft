package com.example.fellowtraveler.ui.privicy

import androidx.lifecycle.ViewModel

class PrivacyPolicyViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}