package com.example.fellowtraveler.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.fellowtraveler.databinding.ItemTouristAttractionBinding
import com.example.fellowtraveler.data.home.TourmateModel

class TouristAdapter(private val dataList: List<TourmateModel>) :
    RecyclerView.Adapter<TouristAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemTouristAttractionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val dataItem = dataList[position]
        holder.bind(dataItem)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    class ViewHolder(private val binding: ItemTouristAttractionBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(dataItem: TourmateModel) {
            binding.data = dataItem
            binding.executePendingBindings()
        }
    }
}
