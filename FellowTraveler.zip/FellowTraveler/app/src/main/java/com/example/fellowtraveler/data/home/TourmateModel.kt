package com.example.fellowtraveler.data.home

data class TourmateModel(
    val name: String,
    val age: Int,
    val destination: String,
    val imageUrl: String // You can replace this with the actual image URL or resource ID as needed
)
