package com.example.fellowtraveler.ui.subscription.monthly

import androidx.lifecycle.ViewModel

class MonthlyPayViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}