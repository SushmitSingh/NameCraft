package com.example.fellowtraveler.ui.auth.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.fellowtraveler.databinding.OnbordingScreenBinding

class BoardingLayout : Fragment() {

    private lateinit var binding: OnbordingScreenBinding


    companion object {
        private const val ARG_IMAGE_RES_ID = "image_res_id"
        private const val ARG_TITLE_TEXT = "title_text"
        private const val ARG_SUBTITLE_TEXT = "subtitle_text"

        fun newInstance(
            imageResId: Int,
            titleText: String,
            subtitleText: String,
        ): BoardingLayout {
            val args = Bundle().apply {
                putInt(ARG_IMAGE_RES_ID, imageResId)
                putString(ARG_TITLE_TEXT, titleText)
                putString(ARG_SUBTITLE_TEXT, subtitleText)
            }
            return BoardingLayout().apply { arguments = args }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = OnbordingScreenBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.let {
            val imageResId = it.getInt(ARG_IMAGE_RES_ID)
            val titleText = it.getString(ARG_TITLE_TEXT)
            val subtitleText = it.getString(ARG_SUBTITLE_TEXT)

            binding.title.setImageResource(imageResId)
            binding.textView.text = titleText
            binding.textView2.text = subtitleText
        }
    }
}